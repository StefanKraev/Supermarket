#pragma once
#include "MyString.h"

class Category
{
	MyString categoryName;
	MyString description;
};

